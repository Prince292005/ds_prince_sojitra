Market Sentiment vs Trader Behavior

This project analyzes how trader behavior changes under different market sentiment
regimes using historical trading data and the Bitcoin Fear & Greed Index.

Files in this folder:
- report.pdf : Final project report
- notebook.ipynb : Complete analysis notebook
- csv_files : Cleaned datasets
- outputs : Graph images

Methodology:
- Daily aggregation of trading data
- Nearest-date sentiment alignment
- Analysis of PnL, volume, and win rate
